package com.BackEnd.PruebaFullStackV4.Controlador;

import com.BackEnd.PruebaFullStackV4.Servicios.FrutasServicio;
import com.BackEnd.PruebaFullStackV4.dto.FrutasDto;
import com.BackEnd.PruebaFullStackV4.dto.Mensaje;
import com.BackEnd.PruebaFullStackV4.entity.RegistrarFrutas;
import com.BackEnd.PruebaFullStackV4.repositorio.FrutasRepositorio;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/fruta")
//@CrossOrigin (origins = "http://localhost:4200")
public class FrutasControlador {
    @Autowired
    FrutasServicio frutasServicio;
    private final FrutasRepositorio frutasRepositorio;

    public FrutasControlador(FrutasRepositorio frutasRepositorio) {
        this.frutasRepositorio = frutasRepositorio;
    }

    @PostMapping
    public RegistrarFrutas crearFruta(@RequestBody RegistrarFrutas fruta) {
        return frutasRepositorio.save(fruta);
    }

    @GetMapping
    public Page<RegistrarFrutas> obtenerListaPaginada(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ){
        Pageable pageable = PageRequest.of(page, size);
        return frutasRepositorio.findAll(pageable);
    }

    @GetMapping("/lista")
    public ResponseEntity<List<RegistrarFrutas>> list(){
        List<RegistrarFrutas> list = frutasServicio.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @GetMapping("/detail/{id}")
    public ResponseEntity<RegistrarFrutas> getById(@PathVariable("id")int id){
        if (!frutasServicio.existsById(id))
            return new ResponseEntity(new Mensaje("La fruta no existe!"), HttpStatus.NOT_FOUND);
        RegistrarFrutas registrarFrutas = frutasServicio.getOne(id).get();
        return new ResponseEntity(registrarFrutas, HttpStatus.OK);
    }

    @GetMapping("/detail/{tipoFruta}")
    public ResponseEntity<RegistrarFrutas> getByTipoFruta(@PathVariable("tipoFruta")String tipoFruta){
        if (!frutasServicio.existsByTipoFruta(tipoFruta))
            return new ResponseEntity(new Mensaje("La fruta no existe!"), HttpStatus.NOT_FOUND);
        RegistrarFrutas registrarFrutas = frutasServicio.getByTipoFruta(tipoFruta).get();
        return new ResponseEntity(registrarFrutas, HttpStatus.OK);
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody FrutasDto frutasDto){
        if (StringUtils.isBlank(frutasDto.getTipoFruta()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        if (frutasDto.getPrecioFruta()== null || frutasDto.getPrecioFruta()<0)
            return new ResponseEntity(new Mensaje("El precio debe ser superior a cero (0)"), HttpStatus.BAD_REQUEST);

        if (frutasServicio.existsByTipoFruta(frutasDto.getTipoFruta()))
            return new ResponseEntity(new Mensaje("El nombre ya existe"), HttpStatus.BAD_REQUEST);
        RegistrarFrutas registrarFrutas = new RegistrarFrutas(frutasDto.getTipoFruta(), frutasDto.getCantidadFruta(), frutasDto.getPrecioFruta());
        frutasServicio.save(registrarFrutas);

        return new ResponseEntity(new Mensaje("Fruta registrado, Exitosamente!"), HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> update(@PathVariable("id")int id, @RequestBody FrutasDto frutasDto){
        if (!frutasServicio.existsById(id))
            return new ResponseEntity(new Mensaje("El id del no existe"), HttpStatus.NOT_FOUND);

        if (frutasServicio.existsByTipoFruta(frutasDto.getTipoFruta()) && frutasServicio.getByTipoFruta(frutasDto.getTipoFruta()).get().getId() != id)
            return new ResponseEntity(new Mensaje("El nombre ya existe"), HttpStatus.BAD_REQUEST);

        if (StringUtils.isBlank(frutasDto.getTipoFruta()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        if (frutasDto.getPrecioFruta() == null || frutasDto.getPrecioFruta()<0)
            return new ResponseEntity(new Mensaje("El precio debe ser superior a cero (0)"), HttpStatus.BAD_REQUEST);

        RegistrarFrutas registrarFrutas = frutasServicio.getOne(id).get();
        registrarFrutas.setTipoFruta(frutasDto.getTipoFruta());
        registrarFrutas.setCantidadFruta(frutasDto.getCantidadFruta());
        registrarFrutas.setPrecioFruta(frutasDto.getPrecioFruta());
        frutasServicio.save(registrarFrutas);

        return new ResponseEntity(new Mensaje("Fruta actualizado, Exitosamente!"), HttpStatus.OK);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<?> delete(@PathVariable("id")int id){
        if (!frutasServicio.existsById(id))
            return new ResponseEntity(new Mensaje("El id del no existe"), HttpStatus.NOT_FOUND);
        frutasServicio.delete(id);
        return new ResponseEntity(new Mensaje("Fruta eliminada, exitosamente!"), HttpStatus.OK);
    }

}
