package com.BackEnd.PruebaFullStackV4.Controlador;

import com.BackEnd.PruebaFullStackV4.entity.Pedidos;
import com.BackEnd.PruebaFullStackV4.repositorio.PedidosRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/api/pedidos")
public class PedidosControlador {
    @Autowired
    private  PedidosRepositorio pedidosRepositorio;

    @PostMapping
    public ResponseEntity<Pedidos> crearPedidos(@RequestBody Pedidos pedidos){
        pedidos.setFechaCreacion(new Date());
        pedidos.setFechaActualizacion(new Date());
        Pedidos nuevoPedido = pedidosRepositorio.save(pedidos);
        return ResponseEntity.ok(nuevoPedido);
    }
}
