package com.BackEnd.PruebaFullStackV4.dto;

import lombok.Data;

@Data
public class FrutasDto {
    private String tipoFruta;
    private Integer cantidadFruta;
    private Float precioFruta;

    public FrutasDto() {
    }

    public FrutasDto(String tipoFruta, Integer cantidadFruta, Float precioFruta) {
        this.tipoFruta = tipoFruta;
        this.cantidadFruta = cantidadFruta;
        this.precioFruta = precioFruta;
    }
}
