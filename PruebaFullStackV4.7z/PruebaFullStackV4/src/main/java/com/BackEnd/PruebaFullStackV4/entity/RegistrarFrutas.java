package com.BackEnd.PruebaFullStackV4.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Entity
@Table(name = "frutas")

public class RegistrarFrutas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private String tipoFruta;
    private int cantidadFruta;
    private double precioFruta;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fechaCreacion")
    private LocalDateTime fechaCreacion;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fechaActualizacion")
    private LocalDateTime fechaActualizacion;

    public RegistrarFrutas() {
    }
    public RegistrarFrutas(String tipoFruta, int cantidadFruta, double precioFruta) {
        this.tipoFruta = tipoFruta;
        this.cantidadFruta = cantidadFruta;
        this.precioFruta = precioFruta;
    }
    public void setFechaCreacion(Date date) {
    }
}
