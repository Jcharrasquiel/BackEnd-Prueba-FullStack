package com.BackEnd.PruebaFullStackV4.repositorio;

import com.BackEnd.PruebaFullStackV4.entity.RegistrarFrutas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FrutasRepositorio extends JpaRepository<RegistrarFrutas, Integer> {
    RegistrarFrutas findByTipoFruta (String tipoFruta);
    boolean existsByTipoFruta(String tipoFruta);
}
