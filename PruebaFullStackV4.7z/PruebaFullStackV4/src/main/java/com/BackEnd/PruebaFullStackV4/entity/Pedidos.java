package com.BackEnd.PruebaFullStackV4.entity;
import jakarta.persistence.*;
import jakarta.persistence.Entity;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@Entity
@Table(name = "pedidos")
public class Pedidos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "text")
    private String listaFrutas;

    private double valorTotal;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fechaCreacion")
    private LocalDateTime fechaCreacion;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fechaActualizacion")
    private LocalDateTime fechaActualizacion;

    public Pedidos() {
    }

    public Pedidos(LocalDateTime fechaCreacion, LocalDateTime fechaActualizacion) {
        this.fechaCreacion = fechaCreacion;
        this.fechaActualizacion = fechaActualizacion;
    }

    public Pedidos(String listaFrutas, double valorTotal, LocalDateTime fechaCreacion, LocalDateTime fechaActualizacion) {
        this.listaFrutas = listaFrutas;
        this.valorTotal = valorTotal;
        this.fechaCreacion = fechaCreacion;
        this.fechaActualizacion = fechaActualizacion;
    }

    public void setFechaActualizacion(Date date) {
    }

    public void setFechaCreacion(Date date) {
    }
}
