package com.BackEnd.PruebaFullStackV4.repositorio;

import com.BackEnd.PruebaFullStackV4.entity.Pedidos;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PedidosRepositorio extends JpaRepository<Pedidos, Integer> {

}
