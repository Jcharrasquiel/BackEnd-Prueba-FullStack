package com.BackEnd.PruebaFullStackV4.Servicios;

import com.BackEnd.PruebaFullStackV4.entity.Pedidos;
import com.BackEnd.PruebaFullStackV4.entity.RegistrarFrutas;
import com.BackEnd.PruebaFullStackV4.repositorio.FrutasRepositorio;
import com.BackEnd.PruebaFullStackV4.repositorio.PedidosRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class PedidosServicios {
    @Autowired
    private final PedidosRepositorio pedidosRepositorio;
    private final FrutasRepositorio frutasRepositorio;

    public PedidosServicios(PedidosRepositorio pedidosRepositorio, FrutasRepositorio frutasRepositorio) {
        this.pedidosRepositorio = pedidosRepositorio;
        this.frutasRepositorio = frutasRepositorio;
    }

    public Pedidos crearPedidos(List<String> tiposFruta, List<Integer> cantidades){
        double valorTotal = 0;

        StringBuilder listaFrutas = new StringBuilder();
        for (int i=0; i<tiposFruta.size(); i++){
            String tipoFrutas = tiposFruta.get(i);
            int cantidad = cantidades.get(i);

            RegistrarFrutas registrarFrutas = frutasRepositorio.findByTipoFruta(tipoFrutas);
            if (registrarFrutas == null){
                throw new IllegalArgumentException("La fruta "+tipoFrutas+" no existe");
            }if (cantidad>registrarFrutas.getCantidadFruta()){
                throw new IllegalArgumentException("La fruta"+tipoFrutas+" esta agotada");
            }

            double precio = registrarFrutas.getPrecioFruta();
            valorTotal += precio * cantidad;

            listaFrutas.append(tipoFrutas).append(" : ").append(cantidad).append(", ");
            registrarFrutas.setCantidadFruta(registrarFrutas.getCantidadFruta() - cantidad);
        }

        Pedidos pedidos = new Pedidos();
        pedidos.setListaFrutas(listaFrutas.toString());
        pedidos.setValorTotal(valorTotal);
        pedidos.setFechaCreacion(new Date());
        pedidos.setFechaActualizacion(new Date());
        pedidosRepositorio.save(pedidos);

        return pedidos;
    }

   /* public void crearPedido(Map<String, Integer> frutasCantidad){
        ObjectMapper objectMapper = new ObjectMapper();
        String listaFrutasJson = null;
        try {
            listaFrutasJson = objectMapper.writeValueAsString(frutasCantidad);
        }catch (JsonProcessingException e){
            e.printStackTrace();
        }

        double valorTotal = 0;
        for (Map.Entry<String, Integer> entry : frutasCantidad.entrySet()){
            RegistrarFrutas registrarFrutas =
        }
    }*/
}
