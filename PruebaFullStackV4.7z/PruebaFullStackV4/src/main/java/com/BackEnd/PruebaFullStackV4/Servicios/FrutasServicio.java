package com.BackEnd.PruebaFullStackV4.Servicios;

import com.BackEnd.PruebaFullStackV4.entity.RegistrarFrutas;
import com.BackEnd.PruebaFullStackV4.repositorio.FrutasRepositorio;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class FrutasServicio {
    @Autowired
    FrutasRepositorio frutasRepositorio;

    public List<RegistrarFrutas> list(){
        return frutasRepositorio.findAll();
    }
    public Optional<RegistrarFrutas> getOne(int id){
        return frutasRepositorio.findById(id);
    }

    public Optional<RegistrarFrutas> getByTipoFruta(String tipoFruta){
        return Optional.ofNullable(frutasRepositorio.findByTipoFruta(tipoFruta));
    }

    public void save(RegistrarFrutas registrarFrutas){
        registrarFrutas.setFechaCreacion(new Date());
        frutasRepositorio.save(registrarFrutas);
    }

    public List<RegistrarFrutas> obtenerListaPaginada(int tamanoPagina, int numeroPagina){
        int offset = (numeroPagina -1 ) * tamanoPagina;
        return frutasRepositorio.findAll(PageRequest.of(offset, tamanoPagina)).getContent();
    }
    public void delete(int id){
        frutasRepositorio.deleteById(id);
    }

    public boolean existsById(int id){
        return frutasRepositorio.existsById(id);
    }

    public boolean existsByTipoFruta(String tipoFruta){
        return frutasRepositorio.existsByTipoFruta(tipoFruta);
    }

}
